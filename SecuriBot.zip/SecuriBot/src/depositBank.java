import java.util.Scanner;
public class depositBank extends storeBankAcc {
    public depositBank() {
        //Set variables
        Scanner userResponse = new Scanner(System.in);
        System.out.println("Please enter the amount of money to deposit");
        double userRespondVar = userResponse.nextDouble();
        double bankState = (double) bankAccountsCreated.get(storeVarI).get(2);
        double finRes =  bankState + userRespondVar;
        bankAccountsCreated.get(storeVarI).set(2, finRes);
        System.out.println("You now have " + bankAccountsCreated.get(storeVarI).get(2) + " dollars");
        new IdVerification();
    }
}
