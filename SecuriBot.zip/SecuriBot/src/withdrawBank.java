import java.util.Scanner;
public class withdrawBank extends storeBankAcc{
    Scanner userResponse12 = new Scanner(System.in);
    public withdrawBank() {
        System.out.println("How much do you want to withdraw?");
        double userResponse = userResponse12.nextDouble();
        double convertToDouble = (double) bankAccountsCreated.get(storeVarI).get(2);
        double finalCard = convertToDouble + userResponse;
        bankAccountsCreated.get(storeVarI).set(2, finalCard);
        System.out.println("You withdrawn " + finalCard + " dollars");
        new IdVerification();
    }
}
