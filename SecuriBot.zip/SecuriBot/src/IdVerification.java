import java.util.Scanner;
public class IdVerification extends storeBankAcc{
    public IdVerification() {
        System.out.println("Welcome to Maze Bank. To begin please enter the pin below to begin.");
        boolean idVerified = false;
        while (!idVerified){
            Scanner nameID = new Scanner(System.in);
            int idInput = nameID.nextInt();
            for (int i = 0; i < bankAccountsCreated.size(); i++) {
                if ((int) bankAccountsCreated.get(i).get(0) == idInput) {
                    System.out.println("You have successfully logged in");
                    idVerified = true;
                    this.storeVarI = i;
                    break;
                }
            }
            if (idVerified){
                System.out.println("Your name is " + bankAccountsCreated.get(storeVarI).get(1));
                System.out.println("Your date of birth is " + bankAccountsCreated.get(storeVarI).get(3));
                System.out.println("Your bank balance is " + bankAccountsCreated.get(storeVarI).get(2));

                //Creates another scanner
                Scanner depoOrWithdrawal = new Scanner(System.in);
                System.out.println("Would you like to deposit or would you like to withdraw?");
                String userRespond = depoOrWithdrawal.nextLine();
                if (userRespond.equalsIgnoreCase("deposit")){
                    new depositBank();
                } else if (userRespond.equalsIgnoreCase("withdraw")){
                    new withdrawBank();
                }
            } else if (idInput > 9999 || idInput < 1000) {
                System.out.println("The pin number must be in 4 digits");
            } else {
                System.out.println("Unknown pin number, contract support for create bank account or assist in recovering current ones.");
            }
        }
    }
}
