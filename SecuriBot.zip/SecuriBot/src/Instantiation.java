public class Instantiation {
    public static void main(String[] args){
        new IdVerification();
    }
}
