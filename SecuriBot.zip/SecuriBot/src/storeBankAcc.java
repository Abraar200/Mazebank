import java.util.ArrayList;
public class storeBankAcc {
    public ArrayList<ArrayList<Object>> bankAccountsCreated = new ArrayList<>();
    int storeVarI = 0;
    public storeBankAcc(){
        bankAccCreator("Anabelle", 1934, 20000.0, "9/11/2010");
        bankAccCreator("John", 1986, 10000.0, "3/25/2003");
    }

    public void bankAccCreator(String name, int pin, double balance, String dateOfBirth){
        //creates part of the array for main array to create 2D ArrayList
        ArrayList<Object> bankParts = new ArrayList<>();
        bankParts.add(Integer.parseInt(String.valueOf(pin)));
        bankParts.add(name);
        bankParts.add(balance);
        bankParts.add(dateOfBirth);

        //Adds to banksAccountsCreated ArrayList
        bankAccountsCreated.add(bankParts);
    }
}
